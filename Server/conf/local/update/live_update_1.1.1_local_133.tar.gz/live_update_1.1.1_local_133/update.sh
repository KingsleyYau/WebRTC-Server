#!/bin/sh

# ---- define folder
curr_folder=$(pwd)
live_folder="$curr_folder/live"
target_folder="/app/live"

# ---- copy stop.sh
if [ -e "$live_folder/bin/stop.sh" ]; then
  cp -f $live_folder/bin/stop.sh /app/live/bin/stop.sh
fi

# ---- stop server
/app/live/bin/stop.sh

# ---- backup nginx conf
now=$(date +%Y%m%d_%H%M%S)
cp -f $target_folder/nginx/conf/nginx.conf $target_folder/nginx/conf/nginx.conf.$now

# ---- Overwrite live file
cp -rf $live_folder/* $target_folder

# ---- run server
/app/live/bin/run.sh
