Chat Tutorial
=============

Goals of this tutorial:
- Implement a realtime websocket chat server


Server
- Nicknames
- Channels
- Subprotocol
- Origin restrictions
- HTTP statistics page
