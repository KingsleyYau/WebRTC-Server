# libsdp - Session Description Protocol library

libsdp is a C library to handle parsing and generating
Session Description Protocol (SDP) strings (see RFC4566).
